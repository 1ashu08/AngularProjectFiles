<?php

date_default_timezone_set('Asia/Kolkata'); // CDT

$info = getdate();
$date = $info['mday'];

echo $date;

?>
