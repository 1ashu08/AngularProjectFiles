var express=require("express");
var bodyParser = require("body-parser");

var app = express();

app.use(bodyParser.urlencoded({
    extended: true
}));


app.use(bodyParser.json());

app.post("/", function (req, res) {
    console.log(req.body.user.name)
    respone.writeHead(200, {'Content-type':'text/plan'});
    response.write('Hello Node JS Server Response');
    response.end( );
});
