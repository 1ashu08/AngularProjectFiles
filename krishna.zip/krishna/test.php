<?php require_once('header.php');  ?>

	<!-- Slider -->
	<div class="slidercontainer">
		<div id="mainslider" class="owl-carousel">

            <div class="item">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="images/slider/slider3.jpg">
                    <div class="container">
                        <div class="col-sm-12 col-md-6 custom-info4-column radius">
                            <div class="thequote">
                                <h5 class="text_dark">What is EDM Smartpay</h5>
                                <p class="text_dark">EDM Smartpay is an on-line platform, having recharge and shopping portals. It also gives an opportunity to earn money from the comfort of your home.</p>
                                <a href="#" class="btn btn-lg btn-new">Join Now</a>
                            </div>
                        </div>
                    </div>
				</div>
            </div>

			<div class="item">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="images/slider/slider2.jpg">
                    <div class="container">
                        <div class="col-sm-12 col-md-8 center-block custom-info-column outer-glow">
                            <div class="thequote">
                                <h5>Earning opportunities with EDM Smartpay</h5>
                                <p>From watching image ads, video ads, shopping portal, recharge portal, learning program to the referrals, there
                                is income opportunities in every step</p>
                                <a href="#" class="btn btn-lg btn-new">Join Now</a>
                            </div>
                        </div>
                    </div>
				</div>
            </div>

			<div class="item">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="images/slider/slider1.png">
                    <div class="container">
                        <div class="col-sm-12 col-md-6 pull-right custom-info3-column radius">
                            <div class="thequote">
                                <h5>TOP REASONS TO WORK Reasons to work with us</h5>
                                <p>FREE TO JOIN,

                                    Free & Unlimited Referrals
                                    Earn Monthly Salary
                                    Unlimited Earning Opportunities
                                    Rewards & Royalty Bonus
                                 </p>
                                <a href="#" class="btn btn-lg btn-new">Join Now</a>
                            </div>
                        </div>
                    </div>
				</div>
            </div>

			<div class="item">
				<div class="row full-width no-gutter section_sapce bg_primary cover-image2" data-image-src="images/slider/slider3.jpg">
                    <div class="container">
                        <div class="col-sm-12 col-md-6 custom-info-column outer-glow">
                            <div class="thequote">
                                <h5>OUR SPECIALITY</h5>
                                <p>Why work alone, refer your friends to use our Video ADs Portal, Image ADs Portal, Recharge Portal, Shopping Portal, Learning Portal and Earn Unlimited Self and Referral Income and Attractive REWARDS. Yes, EDM SMARTPAY helps you achieve your carrer goals.</p>
                                <a href="#" class="btn btn-lg btn-new">Register Now</a>
                            </div>
                        </div>
                    </div>
				</div>
            </div>

		</div>
	</div>
	

	
	  <!-- FAQ -->
	<section class="faq section_sapce">
		<div class="row">
			<div class="container">
				<div class="section-title margin-b50">
					<h2><span>India's Best MLM Company</span>Why Choose Us?</h2>
                </div>
			</div>
		</div>
		<div class="row">
			<div class="container">
				<div class="col-sm-12">
					<div class="faq-questions">
						<div id="accordion" class="panel-group ">

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse1">	Years of Reputation</a></h4> </div>
								<div id="collapse1" class="panel-collapse collapse in">
									<div class="panel-body">
										<p>Since June 2014, we have been carrying out our duties with responsibility, servicing our loyal clients. We keep our clients’ priorities above all issues. We carry this knowledge and expertise to carry your business to the next level with results-driven e-marketing solutions.</p>
									</div>
								</div>
							</div>

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse2">	A wide spectrum of Skills and Experience</a></h4> </div>
								<div id="collapse2" class="panel-collapse collapse">
									<div class="panel-body">
										<p>We handle all aspects of your IT infrastructure in website development, designing, digital marketing, advertising needs, etc. We focus to solve all your issues so that you can focus on growing your business.</p>
									</div>
								</div>
							</div>

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse3">	Quick Response</a></h4> </div>
								<div id="collapse3" class="panel-collapse collapse">
									<div class="panel-body">
										<p>We care for our members. We provide emergency support round the clock. A live person will answer your call or you can enter a service ticket yourself online with our streamlined service ticket system. We are also available in the online chat section on our EDM Smartpay website. </p>
									</div>
								</div>
							</div>

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse4">	Prime Service</a></h4> </div>
								<div id="collapse4" class="panel-collapse collapse">
									<div class="panel-body">
										<p>We believe in assuring you the limelight, earning all the accolades, while we silently work hard in the backdrop. With your support we are growing in leaps and bounds each day. Our networking system is already creating ripples in the market. It is free to join and will always be so. Join us for a rich and fulfilling career.</p>
									</div>
								</div>
							</div>

							<div class="panel panel-default">
								<div class="panel-heading">
									<h4 class="panel-title"><a data-toggle="collapse" data-parent="#accordion" href="#collapse5">	Satisfaction Guaranteed</a></h4> </div>
								<div id="collapse5" class="panel-collapse collapse">
									<div class="panel-body">
										<p>We work hard for your appreciation and recommendation. We want you to be completely satisfied with our services in all fields. We will do whatever it takes to make you happy. No hassles, no worries, no doubts, no problems.</p>
									</div>
								</div>
							</div>

							

						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
    <!-- End of FAQ -->


        




	<!--  Subscribe -->
	<section class="subscribe section_sapce2 bg_dark cover-image" data-image-src="images/subbanners/2.jpg">
		<div class="row">
			<div class="container col-sm-12 col-xs-12 col-md-8 center-block text-center">
            	<div class="col-sm-12 margin-bottom-15">
					<h1>Do you need an EXTRA INCOME ?</h1>
					<p>Then you are welcome here, EDM SMARTPAY gives you that opportunity.</p> 
						 <h4>MAKE YOUR OWN TEAM AND BE YOUR OWN BOSS</h4>
				</div>
				
				<div class="col-sm-12">
					<a href="/members/register_one.php" class="btn btn-primary btn-lg" style="width:100%"><i class="fa fa-check-circle-o"></i> Create your own EDM SMARTPAY Account Now</a> 
				</div>
			</div>
		</div>
	</section>
    <!--  End of Subscribe -->


   


    <!--Service Icons -->
	<section class="container section_sapce">
		<div class="section-title  margin-b50">
			<h2><span>We offer</span></h2>
        </div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-sitemap fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">Joining Bonus</span> </div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-audio-description fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">AD Portal Income</span> </div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-mobile fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">Recharge Income</span> </div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-shopping-bag fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">Shopping Income</span> </div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-graduation-cap fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">Learning Bonus</span> </div>
		</div>
		<div class="col-md-2 col-sm-4 col-xs-6 margin-top-30">
			<div class="service-icon"> <i aria-hidden="true" class="fa fa-money fa-5x text_primary square-border-icon center-block"></i> <span class="service-text">Royalty Income</span> </div>
		</div>
	</section>
    <!--End of Service Icons -->




	<!--APPS Downloads -->
	<section class="section_sapce bg_dark section-parallax parallax cover-image apps-download" data-image-src="images/parallax/technologies-banner.jpg">
        <div class="container ">
            <div class="row">
                <div class="section-title  margin-b50">
                	<h2>Download  <span>Android App</span> Join More & Earn More</h2>
                </div>
            </div>
        </div>
	</section>
    <!--End of APPS Downloads -->

  


 
	<!-- Testimonials 
	<section class="testimonials section_gray section_sapce">
		<div class="row">
			<div class="container">
				<div class="col-sm-12">
					<div class="section-title  margin-b50">
						<h2>What User's Saying</h2>
                    </div>
					<div id="testimonials-carousel" class="owl-carousel">

						<div class="item">
							<div class="testimonial-content">
								<div class="testimonialimg"><img src="images/clients/client1.jpg" alt="" /> </div>
								<p>EarnQuity Infotech has set the new standard for web development in the US! The highest degree of professionalism, turn-around time and code, done right! -- EarnQuity will now be my first stop in shopping for all my internet development needs!</p>
								<div class="whoclient">
									<h5>Dr.Amar Waghmare, Owner of <a href="http://scriptsystech.com">Script Systech Pvt LTD</a></h5>
                                </div>
							</div>
						</div>

						<div class="item">
							<div class="testimonial-content">
								<div class="testimonialimg"><img src="images/clients/client2.jpg" alt="" /> </div>
								<p>They provide great quality for the best prices that I have found in the business. I have been very happy with their work to date and I recommend EarnQuity Infotech highly. Thanks for the good job</p>
								<div class="whoclient">
									<h5>Raghav Soni, Founder of <a href="https://myappthemes.com">MyAppThmes.Com</a></h5>
                                </div>
							</div>
						</div>

					

					</div>
				</div>
			</div>
		</div>
	</section>
	 End of Testimonials -->


<?php require_once('footer.php');  ?>
