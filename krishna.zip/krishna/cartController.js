var app=angular.module('angularApp',[])
                .controller('cartController',function($scope,$http){
                    $scope.Data=JSON.parse(localStorage.getItem("ProductData"));
                    $scope.newData={name:'',quantity:0,price:'0',imagePath:''};
                    $scope.cartStatus={value:'0',visible:false};
		    console.log($scope.Data[0]);
		    $scope.addData=function()
                    {
			//window.alert("Company Data Added");
			$scope.Data.push($scope.newData);
                        $scope.newData={name:'',quantity:0,price:'0',imagePath:''};

			try
			{
				if(parseInt($scope.cartStatus.value)>=0)
				{
					$scope.cartStatus.value=parseInt($scope.cartStatus.value)+1;
					$scope.cartStatus.visible=true;	
								
				}
				else
				{
					$scope.cartStatus.value='0';
					$scope.cartStatus.visible=false;
				}
			}catch(e)
			{
				console.log(e);
			}
                        
                    }	
                                
                });
