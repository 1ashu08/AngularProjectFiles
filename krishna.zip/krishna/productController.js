var app=angular.module('angularApp',[])
	       .controller('productController',function($scope,$http){
				
		url="https://edmsmartpay.com/"+"fetchData.php";
		console.log(url);	
		    $scope.productData=[];
		   var request = $http({
                        method: "post",
                        url:url,
                        data: {
			email: ""
		    	},
			headers: {'Content-Type': 'x-www-form-urlencoded' }
		 	/*headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
			headers: { 'Content-Type': 'application/x-www-form-urlencoded' }*/
			});

			/* Check whether the HTTP Request is successful or not.*/ 
			request.then(function (data) {
				for(var i=0;i<data.data.length;i++)
				{
					var tempProduct=data.data[i].split("+");
					var product;
					if(tempProduct.length>0)
					{
						product={'Name':tempProduct[0],'Description':tempProduct[1],'Category':tempProduct[2],'Size':tempProduct[3],'Price':tempProduct[4],'ImagePath':tempProduct[5]};
						console.log(product.ImagePath);
					}
					else
					{
						product={'Name':"",'Description':"",'Category':"",'Size':"",'Price':"",'ImagePath':""};
					}					
					//console.log(tempProduct);
					$scope.productData.push(product);	
				}
				
				//console.log(typeof(data.data));
				//console.log(data.data);
			});		
	
		});

