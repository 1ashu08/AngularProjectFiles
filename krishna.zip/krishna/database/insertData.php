<?php

	include 'databaseConnection.php';
	
	$conn=databaseConnect();	
	
	$postdata = file_get_contents("php://input");
 	$request = json_decode($postdata);
    	$name = $request->name;
    	$description = $request->description;
	$category=$request->category;
	$price=$request->price;
	$size=$request->size;
	$imagePath="https://edmsmartpay.com/images/".$name.".png";
	
	$sql = "INSERT INTO Product(name,description,category,price,size,imagePath) VALUES('$name','$description','$category','$price','$size','$imagePath')";

	if ($conn->query($sql) === TRUE) {
	    echo "New record created successfully";
	} else {
	    echo "Error: " . $sql . "<br>" . $conn->error;
	}

	$conn->close();

?>

