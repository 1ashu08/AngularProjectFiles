<?php
	function databaseConnect()
	{

		$username="admin_edmt";
		$password="DataRajuMandi550#";
		$database="admin_edmt";

		$conn = new mysqli("localhost", $username, $password, $database);

		if ($conn->connect_error) {
	    		die("Connection failed: " . $conn->connect_error);
		}
		
			echo "Connected successfully";
		return $conn; 	
			#$mysqli->select_db($database) or die( "Unable to select database");
		#mysqli_close($conn); 	
	}
	
?>
