<?php

	include 'databaseConnection.php';
	
	$conn=databaseConnect();	
	
	$sql = "SELECT * FROM Product";
	$result = $conn->query($sql);
	$stack = array();
	

	if ($result->num_rows > 0) {
	
		while($row = $result->fetch_assoc()) {
			$data=$row["Name"]."+".$row["Description"]."+".$row["Category"]."+".$row["Size"]."+".$row["Price"]."+".$row["imagePath"];
			array_push($stack,$data);		
		}
		
		$conn->close();	
		echo $stack;
	} 
	else {
		echo "0 results";
        }
	

?>

