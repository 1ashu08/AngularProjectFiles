var app=angular.module('angularApp',[])
	       .controller('productAddController',function($scope,$http){
				
		var url="https://edmsmartpay.com/"+"insertData.php";
		console.log(url);	
		    /*$scope.productName="";
		    $scope.description="";
		    $scope.category="";
		    $scope.size="";
		    $scope.price="0";	
		    */
		    $scope.product={name:'',description:'',category:'',size:'',price:'0'}		
		    
		     $scope.addProduct=function()
     		     {
			var request = $http({
                        method: "post",
                        url: url,
                        data:$scope.product /*{
			name: $scope.productName,
			description: $scope.description,
			category:$scope.category,
			size:$scope.size,
			price:$scope.price
		    	}*/,
		    	headers: { 'Content-Type': 'x-www-form-urlencoded' }
			});

			/* Check whether the HTTP Request is successful or not. */
			request.then(function (data) {
				console.log(data);
				alert("Data inserted successfull");
			});	
		     }						    	
	    
				
	
		});
