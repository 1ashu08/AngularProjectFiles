var app=angular.module('angularApp',[])
                .controller('productController',function($scope,$http){
                    $scope.Data=[];
                    $scope.ProductData=
			[
				{id:'product1',name:'Visiting Card(type 1)',quantity:0,price:'125',imagePath:'index.jpeg'},
				{id:'product2',name:'Visiting Card(type 1)',quantity:0,price:'125',imagePath:'index.jpeg'}
			]
		    $scope.newData={name:'',quantity:0,price:'0',imagePath:'index.jpeg'};
                    $scope.cartStatus={value:'0',visible:false};
		    $scope.addData=function(productId)
                    {
			/*console.log(productId);
			console.log(document.getElementById("product1Price").value);
			console.log(document.getElementById(productId+"Name").value);
			console.log(document.getElementById(productId+"Quantity").value);
			console.log(document.getElementById(productId+"Image").value);
			//window.alert("Company Data Added");
			*/
			//console.log($scope.newData);
			for(var i=0;i<$scope.ProductData.length;i++)
			{
				if($scope.ProductData[i].id==productId)
				{
					console.log("in if");
					$scope.ProductData[i].quantity=$scope.newData.quantity;
					console.log($scope.ProductData[i].quantity);					
					$scope.Data.push($scope.ProductData[i]);
					$scope.newData={name:'',quantity:'0',price:'0',imagePath:''};

					try
					{
						if(parseInt($scope.cartStatus.value)>=0)
						{
							$scope.cartStatus.value=parseInt($scope.cartStatus.value)+1;
							$scope.cartStatus.visible=true;	
								
						}
						else
						{
							$scope.cartStatus.value='0';
							$scope.cartStatus.visible=false;
						}
					}catch(e)
					{
						console.log(e);
					}						
					break;				
				}
			}
			
                        
                        
                    }
		    $scope.changePage=function()
                    {
			localStorage.removeItem("ProductData");
			localStorage.setItem("ProductData",JSON.stringify($scope.Data));
							
			console.log("I am clicked");
                        
                    }
                                
                });
