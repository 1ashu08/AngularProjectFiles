package org.util.ApplicationTest.controller;

import org.util.ApplicationTest.bean.User;

public class Utility {

	public boolean createUser(User usr)
	{
		return true;
	}
}
