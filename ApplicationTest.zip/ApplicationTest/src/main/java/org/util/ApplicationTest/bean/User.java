package org.util.ApplicationTest.bean;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicLong;

public class User {
	
    @Autowired
    private final IdGenerator idGenerator;
    private String firstName;
    private String lastName;
    private boolean validFlag;
    
    private ArrayList<String> userRole=new ArrayList<String>();
    public User()
    {
    	idGenerator=new IdGenerator();
    	//idGenerator.getNextId();
    }
    
	public AtomicLong getIdGenerator() {
		return idGenerator.getId();
	}	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	
	public ArrayList<String> getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole.add(userRole);
	}
    public void setValidFlag(boolean validFlag)
    {
    	this.validFlag=validFlag;
    }
    public boolean getValidFlag()
    {
    	return validFlag;
    }

}
