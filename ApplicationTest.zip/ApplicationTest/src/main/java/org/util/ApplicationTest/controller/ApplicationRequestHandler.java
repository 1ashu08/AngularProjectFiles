package org.util.ApplicationTest.controller;

import java.util.HashMap;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.util.ApplicationTest.Validator;
import org.util.ApplicationTest.bean.User;


@RestController
@RequestMapping(value="/",produces="application/json")
public class ApplicationRequestHandler {
	
	@RequestMapping(value="/validate/{userName}",method = RequestMethod.GET)
    public ResponseEntity<User> validateUser(@PathVariable String userName) {

		Validator valid=new Validator();
		
		if(valid.isValidUser())
		{
			User usr=valid.fetechUserDetails(userName);
			usr.setValidFlag(true);
			return new ResponseEntity<User>(usr, HttpStatus.OK);
		}
		else
		{
			User usr=new User();
			usr.setValidFlag(false);
			
			return new ResponseEntity<User>(usr, HttpStatus.OK);
		}
        

    }
	
	@RequestMapping(value="/create",method = RequestMethod.GET)
    public ResponseEntity<HashMap<String,String>> createUser(@RequestBody User usr) {

		Utility util=new Utility();
		
		boolean flag=util.createUser(usr);
		HashMap<String,String> map=new HashMap<String,String>();
		if(flag)
		{
			map.put("UserCreationFlag","true");
			map.put("Password","xxyz");
			
			return new ResponseEntity<HashMap<String,String>>(map, HttpStatus.OK);
		}
		else
		{
			map.put("UserCreationFlag","false");
						
			return new ResponseEntity<HashMap<String,String>>(map, HttpStatus.FAILED_DEPENDENCY);
		}

    }
	
	@RequestMapping(value="/error",method = RequestMethod.GET)
    public ResponseEntity<HashMap<String,String>> handleError() {

		
		HashMap<String,String> map=new HashMap<String,String>();
		map.put("Message","An error occured while processing your request");
			
		return new ResponseEntity<HashMap<String,String>>(map, HttpStatus.OK);

    }

	@RequestMapping
    public ResponseEntity<HashMap<String,String>> invalidRequest() {

		HashMap<String,String> map=new HashMap<String,String>();
		map.put("Message","Invalid Request");
			
		return new ResponseEntity<HashMap<String,String>>(map, HttpStatus.OK);

    }
}
